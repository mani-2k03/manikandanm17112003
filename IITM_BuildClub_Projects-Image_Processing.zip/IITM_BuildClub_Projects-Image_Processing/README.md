This repo has projects from "Build club IIT_Madras" 
Here i have two branches image processing and video processing
This branch has image processing projects
  1."Circle draw" this code will make the user to draw using mouse
  2."color track" this code will make the user to adjust colors using trackbars
  3."rectdraw" this code will make the user to draw a rectangle. this will be reference for next code 
  4."crop" this code will make the user to crop a particular area from the image and then cropped image will be displayed in separate window (use tom.jpeg)
  
